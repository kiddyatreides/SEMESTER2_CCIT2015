/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User1
 */
public class LatihanInterface2 implements LatihanInterface{
    @Override
    public void display1()
    {
        
    }
    @Override
    public void display2()
    {
        
    }
    
}
