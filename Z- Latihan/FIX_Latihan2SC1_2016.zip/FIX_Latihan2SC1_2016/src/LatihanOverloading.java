/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User1
 */
public class LatihanOverloading {
    
    public void display(int a)
    {
        
    }
    
    public void display(String A)
    {
        
    }
    
    public void display1(int a, int b)
    {
        
    }
    
}
